//
//  Fighter.hpp
//  CastleTowers
//
//  Created by Ahmed Nezar on 24/12/2022.
//

#ifndef Fighter_hpp
#define Fighter_hpp

#include <stdio.h>
#include "Enemy.hpp"

class Fighter : public Enemy {
public:
    Fighter();
    Fighter(int);
};



#endif /* Fighter_hpp */


