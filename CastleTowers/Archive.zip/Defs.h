#pragma once
#define MinDistance  2 
#define MaxDistance  60 
#define NoOfRegions 4 

enum REGION {
	A_REG,
	B_REG,
	C_REG,
	D_REG,
};

//// type of enemies
//enum TYPE {
//	shielded,
//	balloon,
//	Fighter,
//	Balloon,
//};
