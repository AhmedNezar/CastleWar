//
//  main.cpp
//  CastleTowers
//
//  Created by Ahmed Nezar on 03/12/2022.
//

#include <iostream>
//#include <unistd.h>
#include <thread>
#include <chrono>
#include "Battle.hpp"
#include "GUI.hpp"

using namespace std;

Castle Castle::castles[4] = {Castle(A_REG), Castle(B_REG), Castle(C_REG), Castle(D_REG)};

int main(int argc, const char * argv[]) {
//    Battle b;
//    while(true) {
//        for(int i = 0; i < 4; i++) {
//            Enemy * newEnemy = b.spawn();
//            if(newEnemy != 0) cout << "ID: " << newEnemy->getID() << " - Region: " << newEnemy->getRegion() << " Priority: " << newEnemy->getPriority() << endl;
//        }
//        b.update();
//        chrono::milliseconds timespan(500);
//        this_thread::sleep_for(timespan);
//    }
    GUI gui;
    gui.drawWindow();
    return 0;
}
