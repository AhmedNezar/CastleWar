//
//  Balloon.hpp
//  CastleTowers
//
//  Created by Ahmed Nezar on 24/12/2022.
//

#ifndef Balloon_hpp
#define Balloon_hpp

#include <stdio.h>
#include "Enemy.hpp"

class Balloon : public Enemy {
public:
    Balloon();
    Balloon(int);
};



#endif /* Balloon_hpp */


